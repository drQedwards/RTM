"""Recursive Transformer model wrapper.

This module defines the ``RecursiveTransformerModel`` class, which
augments a base language model with persistent memory, temporal
decay, consensus strengthening and contradiction penalties.  It
implements a simplified version of the ideas presented in the RTM
paper【586403889263000†L322-L361】.
"""

from __future__ import annotations

from datetime import datetime
from typing import Callable, Optional, Tuple

import numpy as np

from .memory import MemoryStore, MemoryBlock
from .decay import exponential_decay
from .consensus import compute_consensus
from .contradiction import compute_contradiction


class RecursiveTransformerModel:
    """Wrap a base model with recursive memory reconsideration.

    A ``RecursiveTransformerModel`` maintains a ``MemoryStore`` of prior
    outputs and updates confidence scores over time using temporal decay,
    consensus and contradiction detection.  When generating new text,
    the wrapper retrieves related memories for context, calls the base
    model, stores the output as a new memory, and updates confidence
    values for existing memories.
    """

    def __init__(
        self,
        base_model: Optional[Callable[[str], str]] = None,
        memory_store: Optional[MemoryStore] = None,
        lambda_param: float = 0.01,
        similarity_threshold: float = 0.7,
    ) -> None:
        """Initialize the model.

        Parameters
        ----------
        base_model : callable, optional
            A function that maps input text to output text.  If not provided,
            a trivial echo function is used.
        memory_store : MemoryStore, optional
            The persistent memory store.  If omitted, a new store is created.
        lambda_param : float
            Decay rate for temporal decay.  Larger values result in faster
            decay of confidence over time.
        similarity_threshold : float
            Threshold used when retrieving related memories.
        """
        self.base_model = base_model if base_model is not None else self._echo_model
        self.memory_store = memory_store if memory_store is not None else MemoryStore(similarity_threshold)
        self.lambda_param = lambda_param

    @staticmethod
    def _echo_model(prompt: str) -> str:
        """A trivial base model that echoes the prompt.

        Users should replace this with a real language model (e.g., from
        HuggingFace) to obtain meaningful outputs.
        """
        return prompt

    def generate(self, prompt: str, now: Optional[datetime] = None) -> Tuple[str, float]:
        """Generate an output for the given prompt.

        The method performs the following steps:

        1. Retrieve memories related to the prompt from the memory store.
        2. Call the base model to generate a response.
        3. Store the response as a new memory with an initial confidence.
        4. Update confidence values of existing memories using temporal decay,
           consensus and contradiction penalties.

        Parameters
        ----------
        prompt : str
            The input text.
        now : datetime, optional
            The current time.  If omitted, ``datetime.utcnow()`` is used.

        Returns
        -------
        (output, confidence) : Tuple[str, float]
            The generated output and its initial confidence in the new memory.
        """
        # Set current time
        if now is None:
            now = datetime.utcnow()
        # Retrieve related memories for the prompt (unused in this simple
        # wrapper, but could be passed to the base model for context)
        _ = self.memory_store.retrieve_related(prompt)
        # Generate output using the base model
        output = self.base_model(prompt)
        # Add new memory with default confidence
        new_confidence = 0.8
        new_memory = MemoryBlock(content=output, confidence=new_confidence, timestamp=now, source="model")
        self.memory_store.add_memory(new_memory)
        # Update existing memories (excluding the newly added one)
        for mem in self.memory_store:
            if mem is new_memory:
                continue
            # Time elapsed in days
            delta_days = (now - mem.timestamp).total_seconds() / (24 * 60 * 60)
            # Decay existing confidence
            decayed_conf = exponential_decay(mem.confidence, self.lambda_param, delta_days)
            # Find related memories for consensus and contradiction detection
            related = self.memory_store.find_related(mem)
            consensus = compute_consensus(mem, related, now)
            contradiction = compute_contradiction(mem, related)
            # Update confidence following the integrated update formula:
            # conf_new = conf_decay * (0.5 + 0.5 * consensus) * exp(-sum contradiction)
            # Note: we use mem.confidence (decayed_conf) inside the update to
            # avoid double decay when recomputing repeatedly.
            mem.confidence = decayed_conf * (0.5 + 0.5 * consensus) * float(np.exp(-contradiction))
        return output, new_confidence