"""Memory structures for the Recursive Transformer.

This module defines the `MemoryBlock` dataclass, representing a single
memory entry, and the `MemoryStore` class, which maintains a collection
of memories and provides retrieval based on cosine similarity.  It uses
TF‑IDF vectorization to embed memory contents into a vector space.  The
implementation is intentionally simple and serves as a reference for
integrating more sophisticated embedding models.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Tuple, Optional

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class MemoryBlock:
    """A single memory entry.

    Attributes
    ----------
    content: str
        The textual claim or piece of knowledge stored in memory.
    confidence: float
        The current confidence score associated with the memory, in the range
        [0, 1].
    timestamp: datetime
        The time at which the memory was created or last updated.
    source: str
        An identifier for the origin of the memory (e.g., "knowledge_base",
        "user", etc.).
    embedding: np.ndarray
        A dense vector representation of the content.  This is computed
        automatically by the ``MemoryStore``.
    """

    content: str
    confidence: float
    timestamp: datetime
    source: str
    embedding: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))


class MemoryStore:
    """A collection of persistent memories with vector‑based retrieval.

    The store maintains a list of ``MemoryBlock`` objects and a TF‑IDF
    vectorizer to embed their content.  It provides methods to add
    memories, recompute embeddings, and retrieve related memories based on
    cosine similarity.
    """

    def __init__(self, similarity_threshold: float = 0.7) -> None:
        self.memories: List[MemoryBlock] = []
        self.similarity_threshold = similarity_threshold
        # The vectorizer is re‑trained when new memories are added.  In a
        # production system, one might use incremental fitting or a
        # pre‑trained embedding model.
        self.vectorizer = TfidfVectorizer()
        self._matrix: Optional[np.ndarray] = None

    def add_memory(self, memory: MemoryBlock) -> None:
        """Add a new memory to the store and update embeddings.

        Parameters
        ----------
        memory: MemoryBlock
            The memory to add.
        """
        self.memories.append(memory)
        self._update_embeddings()

    def _update_embeddings(self) -> None:
        """Fit the vectorizer on all stored memories and assign embeddings.

        When called, this method rebuilds the TF‑IDF representation of
        all memory contents and attaches the resulting vectors to each
        ``MemoryBlock``.  In scenarios where the number of memories grows
        large, consider using an incremental approach or an external
        vector store instead.
        """
        if not self.memories:
            self._matrix = None
            return
        corpus = [m.content for m in self.memories]
        # Fit vectorizer and produce a sparse matrix
        X = self.vectorizer.fit_transform(corpus)
        self._matrix = X.toarray().astype(np.float64)
        # Assign embeddings back to the memory blocks
        for m, vec in zip(self.memories, self._matrix):
            m.embedding = vec

    def retrieve_related(self, query: str) -> List[Tuple[MemoryBlock, float]]:
        """Retrieve memories related to a textual query based on cosine similarity.

        Parameters
        ----------
        query: str
            The textual query for which related memories should be returned.

        Returns
        -------
        List[Tuple[MemoryBlock, float]]
            A list of tuples containing a memory and its similarity to the
            query.  Only memories with similarity above ``similarity_threshold``
            are returned, sorted in descending order of similarity.
        """
        if not self.memories or self._matrix is None:
            return []
        # Transform the query into TF‑IDF space using the existing vocabulary
        query_vec = self.vectorizer.transform([query]).toarray()[0]
        sims = cosine_similarity([query_vec], self._matrix)[0]
        results: List[Tuple[MemoryBlock, float]] = []
        for mem, sim in zip(self.memories, sims):
            if sim >= self.similarity_threshold:
                results.append((mem, float(sim)))
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def find_related(self, memory: MemoryBlock) -> List[Tuple[MemoryBlock, float]]:
        """Retrieve memories related to an existing memory block.

        This method computes cosine similarities between the provided memory's
        embedding and all other stored memories.  Results exclude the
        memory itself and filter by ``similarity_threshold``.

        Parameters
        ----------
        memory: MemoryBlock
            The reference memory for which related memories are sought.

        Returns
        -------
        List[Tuple[MemoryBlock, float]]
            A list of (memory, similarity) pairs.
        """
        if not self.memories or self._matrix is None:
            return []
        if memory.embedding is None or not len(memory.embedding):
            return []
        sims = cosine_similarity([memory.embedding], self._matrix)[0]
        results: List[Tuple[MemoryBlock, float]] = []
        for mem, sim in zip(self.memories, sims):
            if mem is memory:
                continue
            if sim >= self.similarity_threshold:
                results.append((mem, float(sim)))
        results.sort(key=lambda x: x[1], reverse=True)
        return results

    def __len__(self) -> int:
        return len(self.memories)

    def __iter__(self):
        return iter(self.memories)