"""Contradiction detection for memories.

The RTM penalizes memories when conflicting information is discovered
among related entries【586403889263000†L311-L321】.  This module provides a
simple placeholder implementation of contradiction detection.  Users are
encouraged to extend this logic with more robust natural language
processing techniques.
"""

from __future__ import annotations

from typing import List, Tuple

from .memory import MemoryBlock


def compute_contradiction(
    mem: MemoryBlock,
    related: List[Tuple[MemoryBlock, float]],
) -> float:
    """Compute an aggregate contradiction penalty for a memory.

    This simplified function detects contradictions by checking for
    mismatched negation patterns between the content of ``mem`` and
    related memories.  If one statement contains obvious negation
    keywords ("not", "no", "never") and the other does not, a penalty
    proportional to their similarity is applied.  Additional detection
    methods (e.g., entity comparison, semantic entailment) can be added
    for more accurate results.

    Parameters
    ----------
    mem : MemoryBlock
        The memory entry being reconsidered.
    related : list of (MemoryBlock, float)
        A list of other memories and their similarities to ``mem``.

    Returns
    -------
    float
        The sum of contradiction scores.  Values near 0 indicate no
        contradictions; larger values reflect increasing conflict.
    """
    content = mem.content.lower()
    total_penalty = 0.0
    # Simple function to detect negation keywords
    def has_negation(text: str) -> bool:
        text = text.lower()
        return any(kw in text for kw in [" not ", " no ", " never ", " none "])
    mem_neg = has_negation(content)
    for other, sim in related:
        other_neg = has_negation(other.content.lower())
        # If one contains negation and the other does not, treat as a contradiction
        if mem_neg != other_neg:
            total_penalty += sim
    return total_penalty