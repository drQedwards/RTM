"""Top-level package for Recursive Transformer.

This package provides a simplified implementation of the Recursive
Transformer Model (RTM) proposed by Dr. Josef “Q.” Edwards. It includes
classes for managing persistent memories, computing temporal decay and
consensus, performing basic contradiction detection, and integrating
memory into a language model. See the README for details.
"""

from .memory import MemoryBlock, MemoryStore
from .decay import exponential_decay, age_factor
from .consensus import compute_consensus
from .contradiction import compute_contradiction
from .pmll import PMLLNode, PMLLLattice
from .model import RecursiveTransformerModel

__all__ = [
    "MemoryBlock",
    "MemoryStore",
    "exponential_decay",
    "age_factor",
    "compute_consensus",
    "compute_contradiction",
    "PMLLNode",
    "PMLLLattice",
    "RecursiveTransformerModel",
]