"""Consensus computation for memory confidence.

In the Recursive Transformer Model, consensus integrates support from
related memories to strengthen confidence in well‑supported facts【586403889263000†L218-L259】.
This module implements a weighted average consensus calculation.
"""

from __future__ import annotations

from datetime import datetime
from typing import List, Tuple

from .decay import age_factor
from .memory import MemoryBlock


def compute_consensus(
    mem: MemoryBlock,
    related: List[Tuple[MemoryBlock, float]],
    now: datetime,
) -> float:
    """Compute the consensus score for a memory.

    The consensus score aggregates support from related memories.  Each
    related memory contributes based on its similarity to the reference
    memory and its age.  A simple semantic agreement factor of 1 is
    used by default; users can extend this function to incorporate more
    sophisticated agreement metrics.

    Parameters
    ----------
    mem : MemoryBlock
        The memory for which consensus is calculated.
    related : list of (MemoryBlock, float)
        A list of tuples containing other memories and their cosine
        similarity to ``mem``.  Typically returned by ``MemoryStore.find_related``.
    now : datetime
        The current time used to compute age factors.

    Returns
    -------
    float
        The consensus score in the range [0, 1].  If no related
        memories are provided, returns 0.
    """
    if not related:
        return 0.0
    numerator = 0.0
    denominator = 0.0
    for other, sim in related:
        # Age factor reduces influence of older memories
        af = age_factor(other.timestamp, now)
        # Weight combines similarity and age
        weight = sim * af
        # Semantic agreement factor (placeholder)
        a_ij = 1.0
        numerator += weight * a_ij * other.confidence
        denominator += weight
    return numerator / denominator if denominator > 0 else 0.0