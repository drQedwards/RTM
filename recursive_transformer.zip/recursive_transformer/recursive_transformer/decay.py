"""Temporal decay functions for memory confidence.

The original RTM formulation uses exponential decay to reduce the
confidence of memories as they age【586403889263000†L218-L259】.  This module
provides simple implementations of exponential decay and an age factor
used in consensus weighting.
"""

from datetime import datetime
from typing import Union

import numpy as np


def exponential_decay(conf_initial: float, lambda_param: float, time_elapsed: Union[float, int]) -> float:
    """Compute exponential decay of a confidence value.

    Parameters
    ----------
    conf_initial : float
        The initial confidence value at time t0.
    lambda_param : float
        The decay rate (λ).  Higher values result in faster decay.
    time_elapsed : float
        The time elapsed since t0, measured in the same units used when
        defining λ (e.g., days).

    Returns
    -------
    float
        The decayed confidence.
    """
    return float(conf_initial * np.exp(-lambda_param * time_elapsed))


def age_factor(timestamp: datetime, now: datetime) -> float:
    """Compute a simple age factor for consensus weighting.

    The age factor decreases as a memory ages, ensuring newer memories
    contribute more to consensus.  It returns 1 for a fresh memory and
    approaches 0 as the age increases.  The formulation is a reciprocal
    decay: ``1 / (1 + Δt)`` where Δt is the age in days.

    Parameters
    ----------
    timestamp : datetime
        The time the memory was created or last updated.
    now : datetime
        The current time.

    Returns
    -------
    float
        The age factor.
    """
    delta_seconds = (now - timestamp).total_seconds()
    delta_days = delta_seconds / (24 * 60 * 60)
    return 1.0 / (1.0 + delta_days)