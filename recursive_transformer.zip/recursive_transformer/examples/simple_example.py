"""Example usage of the Recursive Transformer implementation.

This script demonstrates how to instantiate a memory store, populate it
with some initial memories, and use the ``RecursiveTransformerModel`` to
generate an output while updating memory confidences.  Run the script
with ``python examples/simple_example.py`` after installing the
dependencies listed in ``requirements.txt``.
"""

from datetime import datetime, timedelta

# Adjust sys.path so that the package can be imported when running this
# script directly from the examples directory.  In normal use, install
# the package (e.g., via ``pip install -e .``) so that imports work
# without modification.
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))

from recursive_transformer import MemoryBlock, MemoryStore, RecursiveTransformerModel


def dummy_model(prompt: str) -> str:
    """Return a canned response to illustrate model integration."""
    return f"Response to: {prompt}"


def main() -> None:
    # Create a memory store with a low similarity threshold to demonstrate retrieval
    store = MemoryStore(similarity_threshold=0.2)
    # Current time
    now = datetime.utcnow()
    # Add initial memories
    mem1 = MemoryBlock(
        content="Paris is the largest city in France.",
        confidence=0.9,
        timestamp=now - timedelta(days=5),
        source="fact",
    )
    mem2 = MemoryBlock(
        content="Paris is the capital of France.",
        confidence=0.8,
        timestamp=now - timedelta(days=2),
        source="fact",
    )
    store.add_memory(mem1)
    store.add_memory(mem2)
    # Instantiate the recursive transformer wrapper with the dummy model
    model = RecursiveTransformerModel(
        base_model=dummy_model,
        memory_store=store,
        lambda_param=0.1,
        similarity_threshold=0.2,
    )
    # Prompt to query
    prompt = "What is the largest city in France?"
    # Generate output (and update memories)
    output, confidence = model.generate(prompt, now=now)
    print(f"Prompt: {prompt}")
    print(f"Generated output: {output}")
    print(f"New memory initial confidence: {confidence:.3f}\n")
    # Show updated memories and their confidences
    print("Updated memories:")
    for m in store:
        print(f"- {m.content} | confidence = {m.confidence:.3f} | timestamp = {m.timestamp.isoformat()}")
    # Retrieve memories relevant to the prompt
    related = store.retrieve_related(prompt)
    print("\nRetrieved memories for prompt:")
    for m, sim in related:
        print(f"- {m.content} (similarity: {sim:.3f})")


if __name__ == "__main__":
    main()