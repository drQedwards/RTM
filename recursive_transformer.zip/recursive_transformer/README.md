# Recursive Transformer (RTM)

This repository contains a reference implementation of the **Recursive Transformer Model** (RTM).
The model is based on the paper *“The Recursive Transformer Model: Architecture, Theory, and Implementation with Persistent Memory Logic Loops”* by Dr. Josef “Q.” Edwards (TechRxiv, Oct 2025)【586403889263000†L218-L259】.  
RTM extends traditional transformer architectures with persistent memory and recursive reconsideration mechanisms designed to reduce **nostalgic incorrectness**—the tendency of stateless AI systems to maintain outdated or contradictory beliefs【586403889263000†L218-L259】.

## Overview

The original paper introduces three primary innovations:

- **Temporal decay:** Memory confidence scores decay over time, reflecting the decreasing reliability of stale information【586403889263000†L218-L259】.
- **Multi‑dimensional consensus:** Confidence is bolstered when multiple related memories agree, using embedding‑based similarity to aggregate support【586403889263000†L218-L259】.
- **Contradiction detection:** Conflicting memories trigger penalties, reducing confidence when evidence contradicts existing beliefs【586403889263000†L311-L321】.

By integrating persistent memory into the embedding layer and attention mechanisms, RTM allows a transformer to retrieve relevant memories, update their confidences, and produce outputs along with a confidence score【586403889263000†L322-L361】.

This repository implements a simplified version of RTM suitable for experimentation and educational purposes. It includes:

- A `MemoryBlock` class to store claims, confidence scores, timestamps, sources and vector embeddings.
- A `MemoryStore` class that manages a collection of `MemoryBlock` objects, performs vectorization, retrieves related memories based on cosine similarity, and updates embeddings.
- Temporal decay and consensus algorithms following the formulations from the paper【586403889263000†L218-L259】.
- A simple contradiction detection placeholder that can be extended.
- A `RecursiveTransformerModel` wrapper that augments a base language model (or placeholder function) with memory retrieval and confidence updates.
- A minimal implementation of the persistent memory logic loop (PMLL) data structure.

For full details of the theoretical framework and algorithms, refer to the original paper.

## Getting Started

Install dependencies (Python ≥ 3.8):

```bash
pip install -r requirements.txt
```

The requirements include `numpy` and `scikit‑learn`. The code avoids heavy deep‑learning libraries; you can integrate your own transformer model in `model.py`.

To run a simple demonstration:

```bash
python examples/simple_example.py
```

The example script instantiates a `MemoryStore`, populates it with a few memories, and uses a dummy base model to generate output. It prints retrieved memories, consensus scores and updated confidences.

## Structure

- `recursive_transformer/` – core Python package
  - `memory.py` – memory classes and store management
  - `decay.py` – temporal decay functions
  - `consensus.py` – consensus computation
  - `contradiction.py` – contradiction detection stub
  - `pmll.py` – persistent memory logic loop placeholder
  - `model.py` – wrapper to integrate memory with a base language model
  - `utils.py` – helper utilities
- `examples/` – sample usage scripts
- `tests/` – unit tests (to be added)
- `README.md` – project overview and instructions
- `LICENSE` – MIT License

## Limitations

This implementation is a simplified proof of concept:

- Embeddings are computed using TF‑IDF vectors instead of transformer encoders.
- Consensus and contradiction detection follow basic heuristics; they should be replaced with more sophisticated models.
- The PMLL lattice and routing algorithms are placeholders.
- A dummy base model is provided for illustration; integration with large language models requires additional work.

## License

This project is licensed under the MIT License. See `LICENSE` for details.